/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.vpc.app.vainruling.plugins.enisoinfo;

import java.util.Random;
import javax.faces.bean.ManagedProperty;
import javax.faces.component.UIInput;
import net.vpc.app.vainruling.core.service.CorePlugin;
import net.vpc.app.vainruling.core.service.model.*;
import net.vpc.app.vainruling.core.web.OnPageLoad;
import net.vpc.app.vainruling.core.web.VrController;
import org.springframework.stereotype.Controller;

/**author
 *
 * @author sudoregex
 */
@VrController(
        menu="/test",
        url="testView"
)
@Controller
public class testCtrl {
    
    CorePlugin core = new CorePlugin();
    public int i = 10;
    public String itest = "Default";
    public UIInput input1;
    public UIInput input2;
    
    public void changeText(){
        try{
            itest = (String) input1.getValue();
        }
        catch(Exception e){}
        
    }

    public UIInput getInput1() {
        return input1;
    }

    public void setInput1(UIInput input1) {
        this.input1 = input1;
    }

    public UIInput getInput2() {
        return input2;
    }

    public void setInput2(UIInput input2) {
        this.input2 = input2;
    }
    

    public String getItest() {
        return itest;
    }

    public void setItest(String itest) {
        this.itest = itest;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
    
    protected String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }
    
    public void saveCountry(){
        AppCountry country = new AppCountry();
        country.setId(0);
        country.setName(getSaltString());
        core.save("AppCountry", country);
    }
    
    public void saveLabTest(){
        LabTest ltest= new LabTest();
        ltest.setId(0);
        ltest.setTitre(itest);
        core.save("LabTest", ltest);
    }
    
    public Model model = new Model();

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }
    
    
    class Model{
        public String testString1 = "DefaultS1";
        public String testString2 = "DefaultS2";
                
        public void changeStringText(){
            testString1 = testString2;
        }
        
    }
    
    
}
