/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.vpc.app.vainruling.plugins.enisoinfo;

import java.util.Date;
import net.vpc.upa.RelationshipType;
import net.vpc.upa.config.Entity;
import net.vpc.upa.config.Id;
import net.vpc.upa.config.ManyToOne;
import net.vpc.upa.config.Sequence;
import net.vpc.upa.config.Summary;

/**
 *
 * @author sudoregex
 */
@Entity
public class LaboArticle {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public LaboChercheur getChercheur() {
        return chercheur;
    }

    public void setChercheur(LaboChercheur chercheur) {
        this.chercheur = chercheur;
    }

    public String getSujet() {
        return sujet;
    }

    public void setSujet(String sujet) {
        this.sujet = sujet;
    }

    public Date getDate_ecrit() {
        return date_ecrit;
    }

    public void setDate_ecrit(Date date_ecrit) {
        this.date_ecrit = date_ecrit;
    }

    public Date getDate_pulication() {
        return date_pulication;
    }

    public void setDate_pulication(Date date_pulication) {
        this.date_pulication = date_pulication;
    }

    public String getFichiers_attachees() {
        return fichiers_attachees;
    }

    public void setFichiers_attachees(String fichiers_attachees) {
        this.fichiers_attachees = fichiers_attachees;
    }
    @Id @Sequence
    private int id;
    
    @Summary
    private String titre;
    
    @ManyToOne(type = RelationshipType.COMPOSITION)
    private LaboChercheur chercheur;
    
    private String sujet;
    
    @Summary
    private Date date_ecrit;
    
    @Summary
    private Date date_pulication;
    
    private String fichiers_attachees;
}
