/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.vpc.app.vainruling.plugins.enisoinfo;

import java.util.Date;
import net.vpc.upa.config.Entity;
import net.vpc.upa.config.Id;
import net.vpc.upa.config.Main;
import net.vpc.upa.config.Sequence;
import net.vpc.upa.config.Summary;

/**
 *
 * @author sudoregex
 */
@Entity
public class LaboChercheurPublication {
    @Id @Sequence @Main
    private int id;
    
    private LaboChercheur chercheur;
    private LaboPublication publication;
    
    @Summary
    private Date date_publication;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LaboChercheur getChercheur() {
        return chercheur;
    }

    public void setChercheur(LaboChercheur chercheur) {
        this.chercheur = chercheur;
    }

    public LaboPublication getPublication() {
        return publication;
    }

    public void setPublication(LaboPublication publication) {
        this.publication = publication;
    }

    public Date getDate_publication() {
        return date_publication;
    }

    public void setDate_publication(Date date_publication) {
        this.date_publication = date_publication;
    }

    public String getFichiers_attachees() {
        return fichiers_attachees;
    }

    public void setFichiers_attachees(String fichiers_attachees) {
        this.fichiers_attachees = fichiers_attachees;
    }
    
    private String fichiers_attachees;
}
