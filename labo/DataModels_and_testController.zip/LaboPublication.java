/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.vpc.app.vainruling.plugins.enisoinfo;

import net.vpc.upa.RelationshipType;
import net.vpc.upa.config.Entity;
import net.vpc.upa.config.Id;
import net.vpc.upa.config.Main;
import net.vpc.upa.config.ManyToOne;
import net.vpc.upa.config.Sequence;

/**
 *
 * @author sudoregex
 */
@Entity
public class LaboPublication {
    @Id @Sequence @Main
    private int id;
    
    @ManyToOne(type=RelationshipType.COMPOSITION)
    private LaboJournal journal;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LaboJournal getJournal() {
        return journal;
    }

    public void setJournal(LaboJournal journal) {
        this.journal = journal;
    }
}
