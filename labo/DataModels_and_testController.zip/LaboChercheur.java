/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.vpc.app.vainruling.plugins.enisoinfo;

import java.util.Date;
import net.vpc.app.vainruling.core.service.model.AppUser;
import net.vpc.upa.config.Entity;
import net.vpc.upa.config.Id;
import net.vpc.upa.config.Main;
import net.vpc.upa.config.Sequence;

/**
 *
 * @author sudoregex
 */
@Entity
public class LaboChercheur {
    @Id @Sequence
    private int id;

    @Main
    private AppUser user;
    
    private Date date_joindre;
    
    private Date date_sortir;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public Date getDate_joindre() {
        return date_joindre;
    }

    public void setDate_joindre(Date date_joindre) {
        this.date_joindre = date_joindre;
    }

    public Date getDate_sortir() {
        return date_sortir;
    }

    public void setDate_sortir(Date date_sortir) {
        this.date_sortir = date_sortir;
    }
}
